package instituto_politecnico;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {

		EstudanteDAO alunoDAO = new EstudanteDAO();
		Scanner teclado = new Scanner(System.in);
		int op = 0;
		String nome;
		String nascimento;
		String CPF;
		int RA;

		do {

			System.out.println("CADASTRO DE ESTUDANTES");
			System.out.println("");
			System.out.println("1 - Cadastrar estudante");
			System.out.println("2 - Listar todos os estudantes cadastrados");
			System.out.println("3 - Pesquisar estudante pelo nome");
			System.out.println("4 - Atualizar cadastro de estudante");
			System.out.println("5 - Remover cadastro de estudante");
			System.out.println("0 - Sair do programa");
			System.out.println("Digite a op��o que deseja realizar:  ");
			
			
			op = Integer.parseInt(teclado.nextLine());

			switch (op) {

			case 1:

				Estudante aluno = new Estudante();
				System.out.println("Digite o nome: ");
				nome = teclado.nextLine();
				System.out.println("Digite a data de nascimento: ");
				nascimento = teclado.nextLine();
				System.out.println("Digite o CPF: ");
				CPF = teclado.nextLine();

				aluno.setNome(nome);
				aluno.setNascimento(nascimento);
				aluno.setCpf(CPF);

				alunoDAO.cadastrar(aluno);
				System.out.println("");
				break;
			case 2:

				for (Estudante a : alunoDAO.getEstudantes()) {
					System.out.println("ID: " + a.getId() + " - Nome: " + a.getNome() + " - Data de nascimento: "
							+ a.getNascimento() + " - CPF: " + a.getCpf());
				}
				System.out.println("");
				break;
			case 3:

				System.out.print("Digite o nome que deseja buscar: ");
				nome = teclado.nextLine();
			
				for (Estudante a1 : alunoDAO.getEstudForNome(nome)) {
					System.out.println("ID: " + a1.getId() + " - Nome: " + a1.getNome() + " - Data de nascimento: "
							+ a1.getNascimento() + " - CPF: " + a1.getCpf());
				}
				System.out.println("");
				break;
			case 4:

				System.out.print("Digite o id que deseja atualizar: ");
				RA = Integer.parseInt(teclado.nextLine());
				System.out.print("Digite o nome: ");
				nome = teclado.nextLine();
				System.out.print("Digite a data de nascimento: ");
				nascimento = teclado.nextLine();
				System.out.print("Digite o CPF: ");
				CPF = teclado.nextLine();

				Estudante a2 = new Estudante();
				
				a2.setNome(nome);
				a2.setNascimento(nascimento);
				a2.setCpf(CPF);
				a2.setId(RA);

				alunoDAO.atualizar(a2);
				System.out.println("");
				break;
			case 5:
				
				System.out.print("Digite o id que deseja deletar: ");
				RA = Integer.parseInt(teclado.nextLine());
				alunoDAO.deletar(RA);
				System.out.println("");
				break;
			case 0:
				System.out.println("SAINDO...");
				break;
			default:
				System.out.println("Op��o Inv�lida, digite novamnete");
				System.out.println("");
				break;
			}

		} while (op != 0);

		teclado.close();
	}

}
