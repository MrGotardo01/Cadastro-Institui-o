package instituto_politecnico;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EstudanteDAO {

	public void cadastrar(Estudante aluno) {

		String sql = "INSERT INTO estudantes(nome, nascimento, CPF) VALUES (?, ?, ?)";

		Connection conn = null;
		PreparedStatement pstm = null;

		try {

			// Criar uma conexao com o BD
			conn = ConnectionFactory.createConnectionToMySQL();

			// Criamos um PreparedStatement, para executar uma query
			pstm = (PreparedStatement) conn.prepareStatement(sql);

			// Adicionar os valores que s�o esperados pela query
			pstm.setString(1, aluno.getNome());
			pstm.setString(2, aluno.getNascimento());
			pstm.setString(3, aluno.getCpf());

			// Executar a query
			pstm.execute();

			System.out.println("Estudante cadastrado com sucesso!");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			// Fechar as conex�es
			try {
				if (pstm != null) {
					pstm.close();
				}

				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public List<Estudante> getEstudantes() {

		String sql = "SELECT * FROM estudantes";

		List<Estudante> estudantes = new ArrayList<Estudante>();

		Connection conn = null;
		PreparedStatement pstm = null;

		// Classe que vai recuperar os dados do banco
		ResultSet rset = null;

		try {
			conn = ConnectionFactory.createConnectionToMySQL();

			pstm = (PreparedStatement) conn.prepareStatement(sql);

			rset = pstm.executeQuery();

			while (rset.next()) {
				Estudante aluno = new Estudante();

				// Recuperar o id
				aluno.setId(rset.getInt("id"));
				// Recuperar o nome
				aluno.setNome(rset.getString("nome"));
				// Recuperar a data de nascimento
				aluno.setNascimento(rset.getString("nascimento"));
				// Recuperar o CPF
				aluno.setCpf(rset.getString("CPF"));

				estudantes.add(aluno);

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rset != null) {
					rset.close();
				}

				if (pstm != null) {
					pstm.close();
				}

				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return estudantes;

	}

	public List<Estudante> getEstudForNome(String nomeAluno) {

		String sql = "SELECT * FROM estudantes WHERE nome LIKE ?";

		List<Estudante> estudantes = new ArrayList<Estudante>();

		Connection conn = null;
		PreparedStatement pstm = null;

		// Classe que vai recuperar os dados do banco
		ResultSet rset = null;

		try {
			conn = ConnectionFactory.createConnectionToMySQL();

			pstm = (PreparedStatement) conn.prepareStatement(sql);
			pstm.setString(1, "%" + nomeAluno + "%"); // nome que deseja buscar

			rset = pstm.executeQuery();

			while (rset.next()) {
				Estudante aluno = new Estudante();

				// Recuperar o id
				aluno.setId(rset.getInt("id"));
				// Recuperar o nome
				aluno.setNome(rset.getString("nome"));
				// Recuperar a data de nascimento
				aluno.setNascimento(rset.getString("nascimento"));
				// Recuperar o CPF
				aluno.setCpf(rset.getString("CPF"));

				estudantes.add(aluno);
			}

		} catch (

		Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rset != null) {
					rset.close();
				}

				if (pstm != null) {
					pstm.close();
				}

				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return estudantes;

	}

	public void atualizar(Estudante aluno) {

		String sql = "UPDATE estudantes SET nome = ?, nascimento = ?, CPF = ? " + "WHERE id = ?";

		Connection conn = null;
		PreparedStatement pstm = null;

		try {

			// Criar uma conexao com o BD
			conn = ConnectionFactory.createConnectionToMySQL();

			// Criamos a classe para executar a query
			pstm = (PreparedStatement) conn.prepareStatement(sql);

			// Adicionar os valores para atualizar
			pstm.setString(1, aluno.getNome());
			pstm.setString(2, aluno.getNascimento());
			pstm.setString(3, aluno.getCpf());

			// Id do registro que deseja atualizar
			pstm.setInt(4, aluno.getId());

			// Executar a query
			pstm.execute();

			System.out.println("Cadastro atualizado com sucesso!");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}

				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void deletar(int id) {

		String sql = "DELETE FROM estudantes WHERE id = ?";

		Connection conn = null;
		PreparedStatement pstm = null;

		try {
			conn = ConnectionFactory.createConnectionToMySQL();

			pstm = (PreparedStatement) conn.prepareStatement(sql);

			pstm.setInt(1, id);

			pstm.execute();
			System.out.println("Cadastro removido com sucesso!");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}

				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
