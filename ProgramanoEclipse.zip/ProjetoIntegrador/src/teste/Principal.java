package teste;

import java.util.Date;

public class Principal {

	public static void main(String[] args) throws Exception{
		
		ContatoDAO contatoDAO = new ContatoDAO();
		
		Contato contato = new Contato();
		contato.setNome("Maria Gabriela");
		contato.setIdade(35);
		contato.setDataCadastro(new Date());
		
		contatoDAO.save(contato);
		
		//Atualizar o contato
		Contato c1 = new Contato();
		c1.setNome("Maria Gabriela Dias Orlando");
		c1.setIdade(37);
		c1.setDataCadastro(new Date());
		c1.setId(1); //� o numero que est� no bd da pk
		
		
		
		//Visualiza��o dos registros do bd
		
		for(Contato c: contatoDAO.getContatos()) {
			System.out.println("Contato: " + c.getNome());
		}
	}

}
